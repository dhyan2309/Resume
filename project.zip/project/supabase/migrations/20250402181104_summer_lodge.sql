/*
  # Create Tourist Places Table

  1. New Tables
    - `tourist_places`
      - `id` (bigint, primary key)
      - `name` (text, not null)
      - `description` (text, not null)
      - `location` (text, not null)
      - `category` (text, not null)
      - `rating` (numeric, not null)
      - `price_range` (text, not null)
      - `best_time` (text, not null)
      - `image_url` (text, not null)
      - `visitor_count` (integer, not null)
      - `created_at` (timestamptz, default now())

  2. Security
    - Enable RLS on `tourist_places` table
    - Add policy for public read access
    - Add policy for authenticated users to create/update places
*/

CREATE TABLE tourist_places (
  id bigint PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  name text NOT NULL,
  description text NOT NULL,
  location text NOT NULL,
  category text NOT NULL,
  rating numeric NOT NULL CHECK (rating >= 0 AND rating <= 5),
  price_range text NOT NULL CHECK (price_range IN ('budget', 'moderate', 'luxury')),
  best_time text NOT NULL,
  image_url text NOT NULL,
  visitor_count integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE tourist_places ENABLE ROW LEVEL SECURITY;

-- Create policy for public read access
CREATE POLICY "Allow public read access"
  ON tourist_places
  FOR SELECT
  TO public
  USING (true);

-- Create policy for authenticated users to create/update places
CREATE POLICY "Allow authenticated users to create places"
  ON tourist_places
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Insert sample data
INSERT INTO tourist_places (name, description, location, category, rating, price_range, best_time, image_url, visitor_count) VALUES
(
  'Machu Picchu',
  'Ancient Incan city set high in the Andes Mountains, featuring remarkable stone architecture and breathtaking views.',
  'Cusco Region, Peru',
  'historical',
  4.9,
  'moderate',
  'April to October',
  'https://images.unsplash.com/photo-1587595431973-160d0d94add1',
  1500000
),
(
  'Santorini',
  'Stunning Greek island known for its white-washed buildings, blue-domed churches, and spectacular sunsets.',
  'Cyclades, Greece',
  'beach',
  4.8,
  'luxury',
  'June to September',
  'https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff',
  2000000
),
(
  'Mount Fuji',
  'Japan''s highest mountain and most iconic natural landmark, perfect for hiking and photography.',
  'Honshu, Japan',
  'mountain',
  4.7,
  'budget',
  'July to August',
  'https://images.unsplash.com/photo-1570789210967-2cac24afeb00',
  1000000
),
(
  'Petra',
  'Ancient city carved into rose-colored rock faces, featuring stunning architecture and rich history.',
  'Ma''an Governorate, Jordan',
  'historical',
  4.8,
  'moderate',
  'March to May',
  'https://images.unsplash.com/photo-1570214476695-19bd467e6f7a',
  800000
),
(
  'Great Barrier Reef',
  'World''s largest coral reef system, offering incredible diving and snorkeling experiences.',
  'Queensland, Australia',
  'adventure',
  4.6,
  'luxury',
  'June to October',
  'https://images.unsplash.com/photo-1582434571786-4bd7fb0a7b61',
  2500000
);
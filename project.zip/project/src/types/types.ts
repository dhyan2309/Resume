// Place Types
export interface Place {
  id: string;
  name: string;
  location: string;
  description: string;
  imageUrl: string;
  rating: number;
  price: number;
  category: string;
  amenities: string[];
  reviews: Review[];
  coordinates: {
    lat: number;
    lng: number;
  };
}

// Review Types
export interface Review {
  id: string;
  userId: string;
  userName: string;
  rating: number;
  comment: string;
  date: string;
}

// Booking Types
export interface Booking {
  id: string;
  placeId: string;
  userId: string;
  checkIn: string;
  checkOut: string;
  guests: number;
  totalPrice: number;
  status: 'pending' | 'confirmed' | 'cancelled';
  createdAt: string;
}

// User Profile Types
export interface UserProfile {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  favoriteIds: string[];
  bookings: Booking[];
}
import React, { useState, useEffect } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getUserBookings, cancelBooking } from '../services/bookingService';
import { getPlaceById } from '../services/placeService';
import { Booking, Place } from '../types/types';
import BookingCard from '../components/booking/BookingCard';

const BookingsPage: React.FC = () => {
  const { isAuthenticated, user } = useAuth();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [places, setPlaces] = useState<{ [key: string]: Place }>({});
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchBookingsAndPlaces = async () => {
      if (!isAuthenticated || !user) return;
      
      setIsLoading(true);
      try {
        // Fetch user bookings
        const userBookings = await getUserBookings(user.id);
        setBookings(userBookings);
        
        // Fetch places for each booking
        const placesMap: { [key: string]: Place } = {};
        
        for (const booking of userBookings) {
          if (!placesMap[booking.placeId]) {
            const place = await getPlaceById(booking.placeId);
            if (place) {
              placesMap[booking.placeId] = place;
            }
          }
        }
        
        setPlaces(placesMap);
      } catch (error) {
        console.error('Error fetching bookings:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchBookingsAndPlaces();
  }, [isAuthenticated, user]);
  
  const handleCancelBooking = async (bookingId: string) => {
    if (!confirm('Are you sure you want to cancel this booking?')) {
      return;
    }
    
    try {
      const success = await cancelBooking(bookingId);
      if (success) {
        // Update the local state
        setBookings(prevBookings => 
          prevBookings.map(booking => 
            booking.id === bookingId 
              ? { ...booking, status: 'cancelled' } 
              : booking
          )
        );
      }
    } catch (error) {
      console.error('Error cancelling booking:', error);
      alert('There was an error cancelling your booking. Please try again.');
    }
  };
  
  if (!isAuthenticated) {
    return <Navigate to="/login" />;
  }

  return (
    <div className="min-h-screen bg-gray-50 pt-24 pb-12">
      <div className="container mx-auto px-4">
        <h1 className="text-2xl font-bold text-gray-800 mb-8">My Bookings</h1>
        
        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
          </div>
        ) : bookings.length === 0 ? (
          <div className="bg-white rounded-lg shadow-sm p-8 text-center">
            <h2 className="text-xl font-semibold mb-2">No bookings yet</h2>
            <p className="text-gray-600 mb-6">You haven't made any bookings yet. Start exploring destinations!</p>
            <a 
              href="/places" 
              className="inline-block px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Discover Places
            </a>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Active Bookings */}
            <div>
              <h2 className="text-xl font-semibold mb-4">Upcoming Trips</h2>
              <div className="space-y-4">
                {bookings
                  .filter(booking => booking.status === 'confirmed')
                  .map(booking => {
                    const place = places[booking.placeId];
                    if (!place) return null;
                    
                    return (
                      <BookingCard
                        key={booking.id}
                        booking={booking}
                        placeName={place.name}
                        placeImage={place.imageUrl}
                        placeLocation={place.location}
                        onCancel={handleCancelBooking}
                      />
                    );
                  })}
              </div>
              
              {bookings.filter(booking => booking.status === 'confirmed').length === 0 && (
                <p className="text-gray-500 italic">No upcoming trips</p>
              )}
            </div>
            
            {/* Past Bookings */}
            {bookings.filter(booking => booking.status === 'cancelled').length > 0 && (
              <div className="mt-10">
                <h2 className="text-xl font-semibold mb-4">Cancelled Bookings</h2>
                <div className="space-y-4">
                  {bookings
                    .filter(booking => booking.status === 'cancelled')
                    .map(booking => {
                      const place = places[booking.placeId];
                      if (!place) return null;
                      
                      return (
                        <BookingCard
                          key={booking.id}
                          booking={booking}
                          placeName={place.name}
                          placeImage={place.imageUrl}
                          placeLocation={place.location}
                        />
                      );
                    })}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default BookingsPage;
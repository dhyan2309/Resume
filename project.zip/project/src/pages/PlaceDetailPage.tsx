import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getPlaceById } from '../services/placeService';
import { Place } from '../types/types';
import PlaceDetail from '../components/places/PlaceDetail';
import { useAuth } from '../context/AuthContext';
import { createBooking } from '../services/bookingService';

const PlaceDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [place, setPlace] = useState<Place | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [bookingDetails, setBookingDetails] = useState({
    placeId: '',
    placeName: '',
    placeImage: '',
    placeLocation: '',
    checkIn: '',
    checkOut: '',
    guests: 0,
    totalPrice: 0,
    bookingId: ''
  });
  const { isAuthenticated, user } = useAuth();
  const navigate = useNavigate();
  
  useEffect(() => {
    const fetchPlace = async () => {
      if (!id) return;
      
      setIsLoading(true);
      try {
        const fetchedPlace = await getPlaceById(id);
        if (fetchedPlace) {
          setPlace(fetchedPlace);
        } else {
          navigate('/places');
        }
      } catch (error) {
        console.error('Error fetching place:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchPlace();
    
    // Load favorites from local storage
    if (isAuthenticated && user) {
      const storedFavorites = localStorage.getItem(`favorites-${user.id}`);
      if (storedFavorites) {
        setFavorites(JSON.parse(storedFavorites));
      }
    }
  }, [id, navigate, isAuthenticated, user]);
  
  const handleToggleFavorite = (placeId: string) => {
    if (!isAuthenticated) {
      alert('Please sign in to save favorites');
      return;
    }
    
    let updatedFavorites: string[];
    
    if (favorites.includes(placeId)) {
      updatedFavorites = favorites.filter(id => id !== placeId);
    } else {
      updatedFavorites = [...favorites, placeId];
    }
    
    setFavorites(updatedFavorites);
    
    // Save to local storage
    if (user) {
      localStorage.setItem(`favorites-${user.id}`, JSON.stringify(updatedFavorites));
    }
  };
  
  const handleBook = async (checkIn: string, checkOut: string, guests: number) => {
    if (!isAuthenticated) {
      alert('Please sign in to book');
      navigate('/login');
      return;
    }
    
    if (!place || !user) return;
    
    try {
      // Calculate number of nights
      const checkInDate = new Date(checkIn);
      const checkOutDate = new Date(checkOut);
      const nights = Math.ceil((checkOutDate.getTime() - checkInDate.getTime()) / (1000 * 60 * 60 * 24));
      
      // Calculate total price (plus 10% service fee)
      const totalPrice = place.price * nights + Math.round(place.price * nights * 0.1);
      
      // Create booking
      const booking = await createBooking(
        place.id,
        user.id,
        checkIn,
        checkOut,
        guests,
        totalPrice
      );
      
      // Set booking details for confirmation page
      setBookingDetails({
        bookingId: booking.id,
        placeId: place.id,
        placeName: place.name,
        placeImage: place.imageUrl,
        placeLocation: place.location,
        checkIn,
        checkOut,
        guests,
        totalPrice
      });
      
      // Navigate to booking confirmation
      navigate('/booking-confirmation', { state: bookingDetails });
    } catch (error) {
      console.error('Error creating booking:', error);
      alert('There was an error processing your booking. Please try again.');
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (!place) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h2 className="text-2xl font-bold">Place not found</h2>
        <p className="mt-4">The destination you're looking for doesn't exist or has been removed.</p>
      </div>
    );
  }

  return (
    <PlaceDetail 
      place={place} 
      isFavorite={favorites.includes(place.id)}
      onToggleFavorite={handleToggleFavorite}
      onBook={handleBook}
    />
  );
};

export default PlaceDetailPage;
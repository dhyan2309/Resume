import React, { useState } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { User, Pencil, Camera, ArrowLeft } from 'lucide-react';

const ProfilePage: React.FC = () => {
  const { isAuthenticated, user, logout } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  
  if (!isAuthenticated || !user) {
    return <Navigate to="/login" />;
  }
  
  const handleSaveProfile = () => {
    // In a real app, this would make an API call to update the user profile
    // For now, we'll just simulate a successful update
    
    // Update local storage user data
    const updatedUser = {
      ...user,
      name,
      email
    };
    
    localStorage.setItem('user', JSON.stringify(updatedUser));
    
    // Turn off editing mode
    setIsEditing(false);
    
    // Reload the page to see the changes reflected
    window.location.reload();
  };
  
  const handleCancelEdit = () => {
    // Reset form to original values
    setName(user.name);
    setEmail(user.email);
    setIsEditing(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-24 pb-12">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <a 
            href="/" 
            className="inline-flex items-center text-blue-600 hover:text-blue-700 mb-6"
          >
            <ArrowLeft size={18} className="mr-1" />
            <span>Back to Home</span>
          </a>
          
          <div className="bg-white rounded-2xl shadow-md overflow-hidden">
            {/* Profile Header */}
            <div className="relative h-48 bg-gradient-to-r from-blue-600 to-blue-400">
              <div className="absolute -bottom-16 left-8">
                <div className="relative">
                  <div className="w-32 h-32 rounded-full bg-gray-200 border-4 border-white overflow-hidden flex items-center justify-center">
                    {/* Profile Image Placeholder */}
                    <User size={64} className="text-gray-400" />
                  </div>
                  <button className="absolute bottom-0 right-0 p-2 bg-blue-500 rounded-full text-white hover:bg-blue-600 transition-colors">
                    <Camera size={16} />
                  </button>
                </div>
              </div>
              
              {!isEditing && (
                <button 
                  onClick={() => setIsEditing(true)}
                  className="absolute top-4 right-4 p-2 bg-white bg-opacity-80 rounded-full hover:bg-opacity-100 transition-colors"
                >
                  <Pencil size={18} className="text-gray-700" />
                </button>
              )}
            </div>
            
            {/* Profile Content */}
            <div className="pt-20 px-8 pb-8">
              {isEditing ? (
                // Edit Form
                <div>
                  <h2 className="text-2xl font-bold mb-6">Edit Profile</h2>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                      <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    
                    <div className="pt-4 flex space-x-4">
                      <button
                        onClick={handleSaveProfile}
                        className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                      >
                        Save Changes
                      </button>
                      <button
                        onClick={handleCancelEdit}
                        className="px-6 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                // Profile View
                <div>
                  <h1 className="text-2xl font-bold mb-1">{user.name}</h1>
                  <p className="text-gray-500 mb-6">{user.email}</p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                    <div className="bg-gray-50 p-5 rounded-lg">
                      <h3 className="font-medium text-gray-700 mb-3">Account Information</h3>
                      <ul className="space-y-2">
                        <li className="flex justify-between">
                          <span className="text-gray-500">Member since</span>
                          <span>{new Date().toLocaleDateString()}</span>
                        </li>
                        <li className="flex justify-between">
                          <span className="text-gray-500">Account Status</span>
                          <span className="text-green-600">Active</span>
                        </li>
                      </ul>
                    </div>
                    
                    <div className="bg-gray-50 p-5 rounded-lg">
                      <h3 className="font-medium text-gray-700 mb-3">Preferences</h3>
                      <ul className="space-y-2">
                        <li className="flex justify-between">
                          <span className="text-gray-500">Language</span>
                          <span>English</span>
                        </li>
                        <li className="flex justify-between">
                          <span className="text-gray-500">Currency</span>
                          <span>USD ($)</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                  
                  <div className="border-t border-gray-200 pt-6">
                    <button
                      onClick={logout}
                      className="px-6 py-2 border border-red-500 text-red-500 rounded-md hover:bg-red-50 transition-colors"
                    >
                      Sign Out
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
import React, { useState, useEffect } from 'react';
import { MapPin, Search, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { getRecommendedPlaces, getPlaces } from '../services/placeService';
import { Place } from '../types/types';
import PlaceCard from '../components/places/PlaceCard';

const HomePage: React.FC = () => {
  const [recommendedPlaces, setRecommendedPlaces] = useState<Place[]>([]);
  const [popularDestinations, setPopularDestinations] = useState<Place[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    const fetchPlaces = async () => {
      try {
        const recommended = await getRecommendedPlaces();
        const allPlaces = await getPlaces();
        
        setRecommendedPlaces(recommended);
        // Sort by rating to get "popular" places
        setPopularDestinations([...allPlaces].sort((a, b) => b.rating - a.rating).slice(0, 3));
        
        setIsLoading(false);
      } catch (error) {
        console.error('Error fetching places:', error);
        setIsLoading(false);
      }
    };
    
    fetchPlaces();
  }, []);
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      window.location.href = `/places?search=${encodeURIComponent(searchQuery)}`;
    }
  };
  
  const categories = [
    { name: 'Beach', image: 'https://images.pexels.com/photos/1078981/pexels-photo-1078981.jpeg' },
    { name: 'Mountain', image: 'https://images.pexels.com/photos/361104/pexels-photo-361104.jpeg' },
    { name: 'City', image: 'https://images.pexels.com/photos/1519088/pexels-photo-1519088.jpeg' },
    { name: 'Desert', image: 'https://images.pexels.com/photos/1001435/pexels-photo-1001435.jpeg' }
  ];

  return (
    <div>
      {/* Hero Section */}
      <div className="relative h-screen min-h-[600px] max-h-[800px] flex items-center justify-center">
        <img 
          src="https://images.pexels.com/photos/2245436/pexels-photo-2245436.png" 
          alt="Travel destination"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black bg-opacity-40"></div>
        
        <div className="relative z-10 container mx-auto px-4 text-center text-white">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">Discover Your Perfect Destination</h1>
          <p className="text-xl md:text-2xl mb-10 max-w-3xl mx-auto">
            Personalized travel recommendations for your next adventure
          </p>
          
          <form onSubmit={handleSearch} className="max-w-2xl mx-auto">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <MapPin size={20} className="text-gray-400" />
                </div>
                <input
                  type="text"
                  placeholder="Where would you like to go?"
                  className="w-full pl-10 pr-4 py-4 rounded-lg text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <button
                type="submit"
                className="md:w-auto bg-blue-600 hover:bg-blue-700 text-white font-medium py-4 px-8 rounded-lg transition-colors duration-200 flex items-center justify-center"
              >
                <Search size={20} className="mr-2" />
                <span>Search</span>
              </button>
            </div>
          </form>
        </div>
      </div>
      
      {/* Categories Section */}
      <div className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Explore by Category</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Discover destinations based on your preferred environment and activities
            </p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {categories.map((category, index) => (
              <Link 
                key={index}
                to={`/places?category=${category.name}`}
                className="group overflow-hidden rounded-xl relative h-64 transition-transform hover:scale-[1.02] shadow-md"
              >
                <img 
                  src={category.image} 
                  alt={category.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-60"></div>
                <div className="absolute bottom-0 left-0 w-full p-6">
                  <h3 className="text-xl font-bold text-white">{category.name}</h3>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
      
      {/* Recommended Places Section */}
      <div className="py-20">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-10">
            <h2 className="text-3xl font-bold text-gray-800">Recommended for You</h2>
            <Link to="/places" className="text-blue-600 hover:text-blue-700 flex items-center font-medium">
              <span>View all</span>
              <ChevronRight size={20} />
            </Link>
          </div>
          
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {recommendedPlaces.map(place => (
                <PlaceCard key={place.id} place={place} />
              ))}
            </div>
          )}
        </div>
      </div>
      
      {/* Popular Destinations Section */}
      <div className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Popular Destinations</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Explore the most-loved destinations from travelers around the world
            </p>
          </div>
          
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {popularDestinations.map(place => (
                <div key={place.id} className="bg-white rounded-xl overflow-hidden shadow-md transform transition-all hover:-translate-y-1 hover:shadow-lg">
                  <Link to={`/place/${place.id}`}>
                    <div className="relative h-60">
                      <img 
                        src={place.imageUrl} 
                        alt={place.name}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-60"></div>
                      <div className="absolute bottom-0 left-0 w-full p-6">
                        <h3 className="text-xl font-bold text-white mb-1">{place.name}</h3>
                        <div className="flex items-center text-white">
                          <MapPin size={16} className="mr-1" />
                          <span className="text-sm">{place.location}</span>
                        </div>
                      </div>
                    </div>
                  </Link>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      
      {/* Newsletter Section */}
      <div className="py-16 bg-blue-700 text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6">Get Travel Inspiration and Deals</h2>
            <p className="mb-8 text-blue-100">
              Subscribe to our newsletter and we'll send you the best travel deals and destination ideas.
            </p>
            
            <form className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto">
              <input
                type="email"
                placeholder="Your email address"
                className="flex-1 px-4 py-3 rounded-lg text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-300"
              />
              <button
                type="submit"
                className="bg-white text-blue-600 hover:bg-blue-50 font-medium py-3 px-6 rounded-lg transition-colors duration-200"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Place } from '../types/types';
import { getPlaces, searchPlaces, filterPlacesByCategory } from '../services/placeService';
import PlaceList from '../components/places/PlaceList';
import { useAuth } from '../context/AuthContext';

const PlacesPage: React.FC = () => {
  const [places, setPlaces] = useState<Place[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [favorites, setFavorites] = useState<string[]>([]);
  const location = useLocation();
  const { isAuthenticated, user } = useAuth();
  
  // Get search params
  const searchParams = new URLSearchParams(location.search);
  const searchQuery = searchParams.get('search');
  const categoryParam = searchParams.get('category');
  
  useEffect(() => {
    const fetchPlaces = async () => {
      setIsLoading(true);
      try {
        let fetchedPlaces: Place[];
        
        if (searchQuery) {
          fetchedPlaces = await searchPlaces(searchQuery);
        } else if (categoryParam) {
          fetchedPlaces = await filterPlacesByCategory(categoryParam);
        } else {
          fetchedPlaces = await getPlaces();
        }
        
        setPlaces(fetchedPlaces);
      } catch (error) {
        console.error('Error fetching places:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchPlaces();
    
    // Load favorites from local storage
    if (isAuthenticated && user) {
      const storedFavorites = localStorage.getItem(`favorites-${user.id}`);
      if (storedFavorites) {
        setFavorites(JSON.parse(storedFavorites));
      }
    }
  }, [searchQuery, categoryParam, isAuthenticated, user]);
  
  const handleToggleFavorite = (placeId: string) => {
    if (!isAuthenticated) {
      alert('Please sign in to save favorites');
      return;
    }
    
    let updatedFavorites: string[];
    
    if (favorites.includes(placeId)) {
      updatedFavorites = favorites.filter(id => id !== placeId);
    } else {
      updatedFavorites = [...favorites, placeId];
    }
    
    setFavorites(updatedFavorites);
    
    // Save to local storage
    if (user) {
      localStorage.setItem(`favorites-${user.id}`, JSON.stringify(updatedFavorites));
    }
  };
  
  let title = 'All Destinations';
  
  if (searchQuery) {
    title = `Search Results for "${searchQuery}"`;
  } else if (categoryParam) {
    title = `${categoryParam} Destinations`;
  }

  return (
    <div className="min-h-screen bg-gray-50 pt-24 pb-12">
      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      ) : (
        <PlaceList 
          places={places} 
          title={title}
          favorites={favorites}
          onToggleFavorite={handleToggleFavorite}
        />
      )}
    </div>
  );
};

export default PlacesPage;
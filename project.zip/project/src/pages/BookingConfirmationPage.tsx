import React from 'react';
import { useLocation, Navigate } from 'react-router-dom';
import BookingConfirmation from '../components/booking/BookingConfirmation';

const BookingConfirmationPage: React.FC = () => {
  const location = useLocation();
  const bookingDetails = location.state;

  if (!bookingDetails) {
    return <Navigate to="/" />;
  }

  return (
    <div className="min-h-screen bg-gray-50 pt-24 pb-12">
      <BookingConfirmation 
        bookingId={bookingDetails.bookingId}
        placeId={bookingDetails.placeId}
        placeName={bookingDetails.placeName}
        placeImage={bookingDetails.placeImage}
        placeLocation={bookingDetails.placeLocation}
        checkIn={bookingDetails.checkIn}
        checkOut={bookingDetails.checkOut}
        guests={bookingDetails.guests}
        totalPrice={bookingDetails.totalPrice}
      />
    </div>
  );
};

export default BookingConfirmationPage;
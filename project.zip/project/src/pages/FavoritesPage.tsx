import React, { useState, useEffect } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getPlaceById } from '../services/placeService';
import { Place } from '../types/types';
import PlaceList from '../components/places/PlaceList';

const FavoritesPage: React.FC = () => {
  const { isAuthenticated, user } = useAuth();
  const [favorites, setFavorites] = useState<string[]>([]);
  const [favoritePlaces, setFavoritePlaces] = useState<Place[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchFavorites = async () => {
      if (!isAuthenticated || !user) return;
      
      // Load favorites from local storage
      const storedFavorites = localStorage.getItem(`favorites-${user.id}`);
      const favoriteIds = storedFavorites ? JSON.parse(storedFavorites) : [];
      setFavorites(favoriteIds);
      
      if (favoriteIds.length === 0) {
        setIsLoading(false);
        return;
      }
      
      // Fetch place details for each favorite
      setIsLoading(true);
      const places: Place[] = [];
      
      for (const id of favoriteIds) {
        try {
          const place = await getPlaceById(id);
          if (place) {
            places.push(place);
          }
        } catch (error) {
          console.error(`Error fetching place ${id}:`, error);
        }
      }
      
      setFavoritePlaces(places);
      setIsLoading(false);
    };
    
    fetchFavorites();
  }, [isAuthenticated, user]);
  
  const handleToggleFavorite = (placeId: string) => {
    // Remove from favorites
    const updatedFavorites = favorites.filter(id => id !== placeId);
    setFavorites(updatedFavorites);
    setFavoritePlaces(prevPlaces => prevPlaces.filter(place => place.id !== placeId));
    
    // Save to local storage
    if (user) {
      localStorage.setItem(`favorites-${user.id}`, JSON.stringify(updatedFavorites));
    }
  };
  
  if (!isAuthenticated) {
    return <Navigate to="/login" />;
  }

  return (
    <div className="min-h-screen bg-gray-50 pt-24 pb-12">
      <div className="container mx-auto px-4">
        <h1 className="text-2xl font-bold text-gray-800 mb-8">My Saved Places</h1>
        
        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
          </div>
        ) : favoritePlaces.length === 0 ? (
          <div className="bg-white rounded-lg shadow-sm p-8 text-center">
            <h2 className="text-xl font-semibold mb-2">No saved places yet</h2>
            <p className="text-gray-600 mb-6">You haven't saved any destinations yet. Start exploring and save places you're interested in!</p>
            <a 
              href="/places" 
              className="inline-block px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Discover Places
            </a>
          </div>
        ) : (
          <PlaceList 
            places={favoritePlaces} 
            title="Saved Places"
            favorites={favorites}
            onToggleFavorite={handleToggleFavorite}
          />
        )}
      </div>
    </div>
  );
};

export default FavoritesPage;
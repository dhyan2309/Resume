import { Booking } from '../types/types';

// Mock bookings data
let mockBookings: Booking[] = [];

export const createBooking = async (
  placeId: string,
  userId: string,
  checkIn: string,
  checkOut: string,
  guests: number,
  totalPrice: number
): Promise<Booking> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 800));
  
  const newBooking: Booking = {
    id: `booking-${Date.now()}`,
    placeId,
    userId,
    checkIn,
    checkOut,
    guests,
    totalPrice,
    status: 'confirmed',
    createdAt: new Date().toISOString()
  };
  
  mockBookings.push(newBooking);
  return newBooking;
};

export const getUserBookings = async (userId: string): Promise<Booking[]> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 600));
  
  return mockBookings.filter(booking => booking.userId === userId);
};

export const cancelBooking = async (bookingId: string): Promise<boolean> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 500));
  
  const bookingIndex = mockBookings.findIndex(booking => booking.id === bookingId);
  
  if (bookingIndex === -1) {
    return false;
  }
  
  mockBookings[bookingIndex].status = 'cancelled';
  return true;
};
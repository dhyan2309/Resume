import { Place } from '../types/types';

// Mock data for places
const mockPlaces: Place[] = [
  // Existing places...
  {
    id: '1',
    name: 'Serene Beach Resort',
    location: 'Bali, Indonesia',
    description: 'Experience the perfect blend of luxury and nature in this stunning beachfront resort with panoramic ocean views.',
    imageUrl: 'https://images.pexels.com/photos/1179156/pexels-photo-1179156.jpeg',
    rating: 4.8,
    price: 250,
    category: 'Beach',
    amenities: ['Pool', 'Spa', 'Restaurant', 'Free WiFi', 'Beach Access'],
    reviews: [
      {
        id: 'r1',
        userId: 'user1',
        userName: 'Sarah Johnson',
        rating: 5,
        comment: 'Absolutely stunning location with impeccable service!',
        date: '2023-05-15'
      },
      {
        id: 'r2',
        userId: 'user2',
        userName: 'Michael Chen',
        rating: 4.5,
        comment: 'Beautiful resort with amazing amenities. The beach was pristine.',
        date: '2023-04-10'
      }
    ],
    coordinates: {
      lat: -8.409518,
      lng: 115.188919
    }
  },

  // Indian Destinations
  {
    id: 'in1',
    name: 'Taj Lake Palace',
    location: 'Udaipur, India',
    description: 'A luxury hotel floating on Lake Pichola, offering royal treatment and breathtaking views of the City Palace.',
    imageUrl: 'https://images.pexels.com/photos/3581368/pexels-photo-3581368.jpeg',
    rating: 4.9,
    price: 550,
    category: 'Heritage',
    amenities: ['Spa', 'Pool', 'Royal Butler', 'Lake View', 'Fine Dining'],
    reviews: [
      {
        id: 'r101',
        userId: 'user101',
        userName: 'Rajesh Patel',
        rating: 5,
        comment: 'Truly a royal experience! The service is impeccable.',
        date: '2024-01-15'
      }
    ],
    coordinates: {
      lat: 24.5754,
      lng: 73.6819
    }
  },
  {
    id: 'in2',
    name: 'The Oberoi Amarvilas',
    location: 'Agra, India',
    description: 'Every room offers a breathtaking view of the Taj Mahal, combining luxury with one of the world\'s most iconic views.',
    imageUrl: 'https://images.pexels.com/photos/3581353/pexels-photo-3581353.jpeg',
    rating: 4.8,
    price: 480,
    category: 'Luxury',
    amenities: ['Taj Mahal View', 'Spa', 'Pool', 'Fine Dining', 'Butler Service'],
    reviews: [],
    coordinates: {
      lat: 27.1731,
      lng: 78.0421
    }
  },
  {
    id: 'in3',
    name: 'Kumarakom Lake Resort',
    location: 'Kerala, India',
    description: 'Traditional Kerala architecture meets luxury in this backwater paradise.',
    imageUrl: 'https://images.pexels.com/photos/3225531/pexels-photo-3225531.jpeg',
    rating: 4.7,
    price: 320,
    category: 'Resort',
    amenities: ['Ayurveda Center', 'Pool', 'Lake View', 'Houseboat', 'Restaurant'],
    reviews: [],
    coordinates: {
      lat: 9.5916,
      lng: 76.4271
    }
  },
  {
    id: 'in4',
    name: 'The Leela Palace',
    location: 'New Delhi, India',
    description: 'Luxury urban hotel combining traditional Indian hospitality with modern amenities.',
    imageUrl: 'https://images.pexels.com/photos/5563472/pexels-photo-5563472.jpeg',
    rating: 4.8,
    price: 400,
    category: 'City',
    amenities: ['Spa', 'Pool', 'Fine Dining', 'Gym', 'Business Center'],
    reviews: [],
    coordinates: {
      lat: 28.5925,
      lng: 77.1873
    }
  },
  {
    id: 'in5',
    name: 'Wildflower Hall',
    location: 'Shimla, India',
    description: 'Former residence of Lord Kitchener, now a luxury resort offering panoramic Himalayan views.',
    imageUrl: 'https://images.pexels.com/photos/2356045/pexels-photo-2356045.jpeg',
    rating: 4.7,
    price: 450,
    category: 'Mountain',
    amenities: ['Mountain Views', 'Spa', 'Indoor Pool', 'Restaurant', 'Adventure Activities'],
    reviews: [],
    coordinates: {
      lat: 31.1048,
      lng: 77.1734
    }
  },

  // New Indian Destinations
  {
    id: 'in6',
    name: 'Evolve Back Coorg',
    location: 'Coorg, Karnataka',
    description: 'Luxury resort nestled in coffee plantations offering authentic Kodava hospitality.',
    imageUrl: 'https://images.pexels.com/photos/338504/pexels-photo-338504.jpeg',
    rating: 4.7,
    price: 380,
    category: 'Resort',
    amenities: ['Coffee Estate Tours', 'Infinity Pool', 'Ayurveda Spa', 'Private Pool Villas', 'Nature Walks'],
    reviews: [],
    coordinates: {
      lat: 12.4244,
      lng: 75.7382
    }
  },
  {
    id: 'in7',
    name: 'The Khyber Himalayan',
    location: 'Gulmarg, Kashmir',
    description: 'Luxury mountain resort with stunning views of the Himalayas and world-class ski facilities.',
    imageUrl: 'https://images.pexels.com/photos/754268/pexels-photo-754268.jpeg',
    rating: 4.8,
    price: 420,
    category: 'Mountain',
    amenities: ['Ski Facilities', 'Spa', 'Heated Pool', 'Mountain Views', 'Adventure Sports'],
    reviews: [],
    coordinates: {
      lat: 34.0494,
      lng: 74.3862
    }
  },
  {
    id: 'in8',
    name: 'Taj Falaknuma Palace',
    location: 'Hyderabad, India',
    description: 'Former palace of the Nizam, offering a glimpse into royal Hyderabadi lifestyle.',
    imageUrl: 'https://images.pexels.com/photos/3225531/pexels-photo-3225531.jpeg',
    rating: 4.9,
    price: 600,
    category: 'Heritage',
    amenities: ['Royal Butler', 'Palace Tours', 'Fine Dining', 'Period Furnishings', 'City Views'],
    reviews: [],
    coordinates: {
      lat: 17.3325,
      lng: 78.4673
    }
  },
  {
    id: 'in9',
    name: 'Spice Village',
    location: 'Thekkady, Kerala',
    description: 'Eco-friendly resort in the heart of spice country, offering authentic Kerala experiences.',
    imageUrl: 'https://images.pexels.com/photos/5563459/pexels-photo-5563459.jpeg',
    rating: 4.6,
    price: 280,
    category: 'Eco',
    amenities: ['Spice Gardens', 'Cooking Classes', 'Nature Walks', 'Ayurveda Center', 'Organic Farm'],
    reviews: [],
    coordinates: {
      lat: 9.5828,
      lng: 77.1830
    }
  },
  {
    id: 'in10',
    name: 'Umaid Bhawan Palace',
    location: 'Jodhpur, India',
    description: 'One of the world\'s largest private residences, part of which is a luxury hotel.',
    imageUrl: 'https://images.pexels.com/photos/3214958/pexels-photo-3214958.jpeg',
    rating: 4.9,
    price: 750,
    category: 'Heritage',
    amenities: ['Museum', 'Palace Tours', 'Spa', 'Private Gardens', 'Royal Butler'],
    reviews: [],
    coordinates: {
      lat: 26.2843,
      lng: 73.0458
    }
  },
  {
    id: 'in11',
    name: 'The Tamara Coorg',
    location: 'Coorg, Karnataka',
    description: 'Luxury cottages perched on a hillside amidst coffee plantations.',
    imageUrl: 'https://images.pexels.com/photos/5563467/pexels-photo-5563467.jpeg',
    rating: 4.7,
    price: 350,
    category: 'Resort',
    amenities: ['Treehouse Dining', 'Coffee Tours', 'Yoga Center', 'Waterfall Views', 'Nature Trails'],
    reviews: [],
    coordinates: {
      lat: 12.4244,
      lng: 75.7382
    }
  },
  {
    id: 'in12',
    name: 'Taj Bekal Resort',
    location: 'Bekal, Kerala',
    description: 'Luxury resort inspired by Kerala\'s traditional architecture, set along the Arabian Sea.',
    imageUrl: 'https://images.pexels.com/photos/338504/pexels-photo-338504.jpeg',
    rating: 4.8,
    price: 420,
    category: 'Beach',
    amenities: ['Private Beach', 'Ayurveda Center', 'Water Sports', 'Laterite Architecture', 'Cooking School'],
    reviews: [],
    coordinates: {
      lat: 12.3925,
      lng: 75.0337
    }
  },
  {
    id: 'in13',
    name: 'The Postcard Dewa',
    location: 'Thimphu, Bhutan',
    description: 'Luxury resort offering panoramic views of the Himalayas and authentic Bhutanese experiences.',
    imageUrl: 'https://images.pexels.com/photos/5563472/pexels-photo-5563472.jpeg',
    rating: 4.8,
    price: 480,
    category: 'Mountain',
    amenities: ['Mountain Views', 'Traditional Architecture', 'Spa', 'Cultural Tours', 'Meditation Center'],
    reviews: [],
    coordinates: {
      lat: 27.4712,
      lng: 89.6339
    }
  },
  {
    id: 'in14',
    name: 'Barefoot at Havelock',
    location: 'Andaman Islands',
    description: 'Eco-friendly beach resort on one of Asia\'s best beaches.',
    imageUrl: 'https://images.pexels.com/photos/1287460/pexels-photo-1287460.jpeg',
    rating: 4.6,
    price: 300,
    category: 'Beach',
    amenities: ['Private Beach', 'Diving Center', 'Eco Tours', 'Beachfront Dining', 'Water Sports'],
    reviews: [],
    coordinates: {
      lat: 11.9667,
      lng: 92.9333
    }
  },
  {
    id: 'in15',
    name: 'Suryagarh',
    location: 'Jaisalmer, Rajasthan',
    description: 'Modern palace hotel offering authentic Rajasthani experiences in the Thar Desert.',
    imageUrl: 'https://images.pexels.com/photos/3581353/pexels-photo-3581353.jpeg',
    rating: 4.7,
    price: 400,
    category: 'Heritage',
    amenities: ['Desert Safaris', 'Spa', 'Traditional Music', 'Indoor Pool', 'Royal Dining'],
    reviews: [],
    coordinates: {
      lat: 26.9157,
      lng: 70.9083
    }
  },
  {
    id: 'in16',
    name: 'Ri Kynjai',
    location: 'Shillong, Meghalaya',
    description: 'Luxury resort inspired by traditional Khasi architecture with views of Umiam Lake.',
    imageUrl: 'https://images.pexels.com/photos/2356045/pexels-photo-2356045.jpeg',
    rating: 4.6,
    price: 280,
    category: 'Resort',
    amenities: ['Lake Views', 'Spa', 'Local Architecture', 'Nature Walks', 'Cultural Tours'],
    reviews: [],
    coordinates: {
      lat: 25.5788,
      lng: 91.8933
    }
  },
  {
    id: 'in17',
    name: 'Ahilya Fort',
    location: 'Maheshwar, Madhya Pradesh',
    description: '18th-century fort converted into a heritage hotel on the banks of the Narmada.',
    imageUrl: 'https://images.pexels.com/photos/3214958/pexels-photo-3214958.jpeg',
    rating: 4.8,
    price: 450,
    category: 'Heritage',
    amenities: ['River Views', 'Temple Tours', 'Textile Workshop', 'Organic Garden', 'Boat Rides'],
    reviews: [],
    coordinates: {
      lat: 22.1783,
      lng: 75.5867
    }
  },
  {
    id: 'in18',
    name: 'Taj Exotica',
    location: 'Andamans',
    description: 'Luxury beach resort on Havelock Island with world-class diving facilities.',
    imageUrl: 'https://images.pexels.com/photos/1179156/pexels-photo-1179156.jpeg',
    rating: 4.9,
    price: 600,
    category: 'Beach',
    amenities: ['Private Beach', 'Diving Center', 'Spa', 'Water Sports', 'Ocean View Villas'],
    reviews: [],
    coordinates: {
      lat: 11.9667,
      lng: 92.9333
    }
  },
  {
    id: 'in19',
    name: 'The Himalayan',
    location: 'Manali, Himachal Pradesh',
    description: 'Gothic-style castle hotel offering luxury accommodations in the Himalayas.',
    imageUrl: 'https://images.pexels.com/photos/754268/pexels-photo-754268.jpeg',
    rating: 4.7,
    price: 380,
    category: 'Mountain',
    amenities: ['Mountain Views', 'Spa', 'Adventure Sports', 'Gothic Architecture', 'Fine Dining'],
    reviews: [],
    coordinates: {
      lat: 32.2432,
      lng: 77.1892
    }
  },
  {
    id: 'in20',
    name: 'Coconut Lagoon',
    location: 'Kumarakom, Kerala',
    description: 'Heritage resort in the backwaters featuring traditional Kerala architecture.',
    imageUrl: 'https://images.pexels.com/photos/3225531/pexels-photo-3225531.jpeg',
    rating: 4.8,
    price: 420,
    category: 'Heritage',
    amenities: ['Backwater Cruises', 'Ayurveda Center', 'Bird Sanctuary', 'Cultural Shows', 'Eco Tours'],
    reviews: [],
    coordinates: {
      lat: 9.5916,
      lng: 76.4271
    }
  },
  {
    id: 'in21',
    name: 'Shakti 360° Leti',
    location: 'Leti, Uttarakhand',
    description: 'Exclusive mountain retreat with panoramic Himalayan views.',
    imageUrl: 'https://images.pexels.com/photos/2356045/pexels-photo-2356045.jpeg',
    rating: 4.9,
    price: 800,
    category: 'Luxury',
    amenities: ['Mountain Views', 'Private Chef', 'Hiking Trails', 'Meditation Space', 'Solar Power'],
    reviews: [],
    coordinates: {
      lat: 30.1982,
      lng: 79.6766
    }
  },
  {
    id: 'in22',
    name: 'Rawla Narlai',
    location: 'Narlai, Rajasthan',
    description: '17th-century royal retreat transformed into a heritage hotel.',
    imageUrl: 'https://images.pexels.com/photos/3214958/pexels-photo-3214958.jpeg',
    rating: 4.7,
    price: 350,
    category: 'Heritage',
    amenities: ['Stepwell Dining', 'Village Tours', 'Horse Riding', 'Heritage Walks', 'Pool'],
    reviews: [],
    coordinates: {
      lat: 25.3333,
      lng: 73.1333
    }
  },
  {
    id: 'in23',
    name: 'Taj Rishikesh',
    location: 'Rishikesh, Uttarakhand',
    description: 'Contemporary resort with views of the Ganges and Himalayas.',
    imageUrl: 'https://images.pexels.com/photos/5563472/pexels-photo-5563472.jpeg',
    rating: 4.8,
    price: 450,
    category: 'Wellness',
    amenities: ['Yoga Studio', 'River Views', 'Spa', 'Adventure Sports', 'Meditation'],
    reviews: [],
    coordinates: {
      lat: 30.1087,
      lng: 78.2946
    }
  },
  {
    id: 'in24',
    name: 'Evolve Back Hampi',
    location: 'Hampi, Karnataka',
    description: 'Luxury resort inspired by the Vijayanagara Empire\'s architectural style.',
    imageUrl: 'https://images.pexels.com/photos/3581368/pexels-photo-3581368.jpeg',
    rating: 4.8,
    price: 420,
    category: 'Heritage',
    amenities: ['Heritage Tours', 'Infinity Pool', 'Spa', 'Archaeological Sites', 'Cultural Programs'],
    reviews: [],
    coordinates: {
      lat: 15.3350,
      lng: 76.4600
    }
  },
  {
    id: 'in25',
    name: 'Mary Budden Estate',
    location: 'Binsar, Uttarakhand',
    description: 'Restored colonial estate offering an intimate mountain retreat experience.',
    imageUrl: 'https://images.pexels.com/photos/2356045/pexels-photo-2356045.jpeg',
    rating: 4.7,
    price: 380,
    category: 'Mountain',
    amenities: ['Forest Views', 'Organic Farm', 'Nature Walks', 'Library', 'Bird Watching'],
    reviews: [],
    coordinates: {
      lat: 29.7025,
      lng: 79.7728
    }
  },

  // International Destinations
  {
    id: 'int1',
    name: 'Santorini Grace',
    location: 'Santorini, Greece',
    description: 'Luxurious boutique hotel with infinity pools overlooking the Aegean Sea.',
    imageUrl: 'https://images.pexels.com/photos/1010657/pexels-photo-1010657.jpeg',
    rating: 4.9,
    price: 600,
    category: 'Beach',
    amenities: ['Infinity Pool', 'Sea View', 'Spa', 'Restaurant', 'Bar'],
    reviews: [],
    coordinates: {
      lat: 36.3932,
      lng: 25.4615
    }
  },
  {
    id: 'int2',
    name: 'Burj Al Arab',
    location: 'Dubai, UAE',
    description: 'Iconic sail-shaped hotel offering ultimate luxury and Arabian hospitality.',
    imageUrl: 'https://images.pexels.com/photos/2044434/pexels-photo-2044434.jpeg',
    rating: 4.9,
    price: 1200,
    category: 'Luxury',
    amenities: ['Butler Service', 'Private Beach', 'Spa', 'Helipad', 'Underwater Restaurant'],
    reviews: [],
    coordinates: {
      lat: 25.1412,
      lng: 55.1854
    }
  },
  {
    id: 'int3',
    name: 'Four Seasons Bora Bora',
    location: 'Bora Bora, French Polynesia',
    description: 'Overwater bungalows in paradise with views of Mount Otemanu.',
    imageUrl: 'https://images.pexels.com/photos/1287460/pexels-photo-1287460.jpeg',
    rating: 4.8,
    price: 1100,
    category: 'Beach',
    amenities: ['Overwater Bungalows', 'Spa', 'Lagoon', 'Restaurant', 'Water Sports'],
    reviews: [],
    coordinates: {
      lat: -16.5004,
      lng: -151.7415
    }
  },
  {
    id: 'int4',
    name: 'Icehotel',
    location: 'Jukkasjärvi, Sweden',
    description: 'Unique hotel rebuilt each winter using ice from the Torne River.',
    imageUrl: 'https://images.pexels.com/photos/3889843/pexels-photo-3889843.jpeg',
    rating: 4.7,
    price: 450,
    category: 'Unique',
    amenities: ['Ice Rooms', 'Northern Lights Views', 'Ice Bar', 'Winter Activities', 'Sauna'],
    reviews: [],
    coordinates: {
      lat: 67.8514,
      lng: 20.6000
    }
  },
  {
    id: 'int5',
    name: 'Giraffe Manor',
    location: 'Nairobi, Kenya',
    description: 'Historic mansion where guests can feed giraffes from their window.',
    imageUrl: 'https://images.pexels.com/photos/5562862/pexels-photo-5562862.jpeg',
    rating: 4.8,
    price: 850,
    category: 'Unique',
    amenities: ['Giraffe Interaction', 'Gardens', 'Restaurant', 'Safari Tours', 'Butler Service'],
    reviews: [],
    coordinates: {
      lat: -1.3833,
      lng: 36.7167
    }
  }
];

export const getPlaces = async (): Promise<Place[]> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 800));
  return mockPlaces;
};

export const getPlaceById = async (id: string): Promise<Place | undefined> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 500));
  return mockPlaces.find(place => place.id === id);
};

export const getRecommendedPlaces = async (): Promise<Place[]> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 800));
  // In a real app, this would use an algorithm to recommend places based on user preferences
  return mockPlaces.slice(0, 4);
};

export const searchPlaces = async (query: string): Promise<Place[]> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 600));
  
  const lowercaseQuery = query.toLowerCase();
  return mockPlaces.filter(place => 
    place.name.toLowerCase().includes(lowercaseQuery) ||
    place.location.toLowerCase().includes(lowercaseQuery) ||
    place.category.toLowerCase().includes(lowercaseQuery) ||
    place.description.toLowerCase().includes(lowercaseQuery)
  );
};

export const filterPlacesByCategory = async (category: string): Promise<Place[]> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 500));
  
  return mockPlaces.filter(place => 
    place.category.toLowerCase() === category.toLowerCase()
  );
};
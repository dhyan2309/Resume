import React, { useState, useEffect } from 'react';
import { Search, MapPin, Star, Globe, Users, Clock, Camera } from 'lucide-react';
import { supabase } from './lib/supabase';

interface TouristPlace {
  id: number;
  name: string;
  description: string;
  location: string;
  category: string;
  rating: number;
  price_range: string;
  best_time: string;
  image_url: string;
  visitor_count: number;
}

function App() {
  const [places, setPlaces] = useState<TouristPlace[]>([]);
  const [filters, setFilters] = useState({
    category: '',
    minRating: 0,
    location: '',
    priceRange: '',
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchPlaces();
  }, []);

  const fetchPlaces = async () => {
    setLoading(true);
    try {
      let query = supabase
        .from('tourist_places')
        .select('*');

      if (filters.category) {
        query = query.eq('category', filters.category);
      }
      if (filters.minRating > 0) {
        query = query.gte('rating', filters.minRating);
      }
      if (filters.location) {
        query = query.ilike('location', `%${filters.location}%`);
      }
      if (filters.priceRange) {
        query = query.eq('price_range', filters.priceRange);
      }

      const { data, error } = await query;
      if (error) throw error;
      setPlaces(data || []);
    } catch (error) {
      console.error('Error fetching places:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchPlaces();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      <div className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-indigo-600 to-purple-600 px-8 py-12 relative overflow-hidden">
            <div className="absolute inset-0 bg-black opacity-10"></div>
            <div className="relative">
              <h1 className="text-4xl font-bold text-white mb-4">
                Tourist Place Finder
              </h1>
              <p className="text-indigo-100 text-lg">
                Discover amazing destinations tailored to your preferences
              </p>
            </div>
          </div>

          {/* Search Form */}
          <form onSubmit={handleSubmit} className="px-8 py-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Category
                </label>
                <select
                  className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  value={filters.category}
                  onChange={(e) => setFilters({ ...filters, category: e.target.value })}
                >
                  <option value="">All Categories</option>
                  <option value="beach">Beaches</option>
                  <option value="mountain">Mountains</option>
                  <option value="historical">Historical Sites</option>
                  <option value="cultural">Cultural Sites</option>
                  <option value="adventure">Adventure Spots</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Minimum Rating
                </label>
                <select
                  className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  value={filters.minRating}
                  onChange={(e) => setFilters({ ...filters, minRating: Number(e.target.value) })}
                >
                  {[0, 1, 2, 3, 4, 5].map((rating) => (
                    <option key={rating} value={rating}>
                      {rating} {rating === 1 ? 'Star' : 'Stars'}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Location
                </label>
                <input
                  type="text"
                  className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  placeholder="Enter location"
                  value={filters.location}
                  onChange={(e) => setFilters({ ...filters, location: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Price Range
                </label>
                <select
                  className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  value={filters.priceRange}
                  onChange={(e) => setFilters({ ...filters, priceRange: e.target.value })}
                >
                  <option value="">Any Price</option>
                  <option value="budget">Budget</option>
                  <option value="moderate">Moderate</option>
                  <option value="luxury">Luxury</option>
                </select>
              </div>
            </div>

            <div className="flex justify-center">
              <button
                type="submit"
                className="px-8 py-3 bg-indigo-600 text-white font-medium rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition-colors"
                disabled={loading}
              >
                <Search className="w-5 h-5 inline-block mr-2" />
                {loading ? 'Searching...' : 'Find Places'}
              </button>
            </div>
          </form>

          {/* Results Grid */}
          <div className="px-8 py-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {places.length === 0 ? (
                <div className="col-span-full text-center py-12 text-gray-500">
                  No places found. Try adjusting your search filters.
                </div>
              ) : (
                places.map((place) => (
                  <div
                    key={place.id}
                    className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow"
                  >
                    <div className="h-48 overflow-hidden">
                      <img
                        src={place.image_url}
                        alt={place.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="p-6">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="text-xl font-semibold text-gray-900">
                          {place.name}
                        </h3>
                        <div className="flex items-center">
                          <Star className="w-5 h-5 text-yellow-400" />
                          <span className="ml-1 text-gray-700">{place.rating}</span>
                        </div>
                      </div>
                      <p className="text-gray-600 mb-4 line-clamp-2">
                        {place.description}
                      </p>
                      <div className="space-y-2">
                        <div className="flex items-center text-gray-500">
                          <MapPin className="w-4 h-4 mr-2" />
                          <span>{place.location}</span>
                        </div>
                        <div className="flex items-center text-gray-500">
                          <Globe className="w-4 h-4 mr-2" />
                          <span>{place.category}</span>
                        </div>
                        <div className="flex items-center text-gray-500">
                          <Clock className="w-4 h-4 mr-2" />
                          <span>{place.best_time}</span>
                        </div>
                        <div className="flex items-center justify-between text-gray-500">
                          <div className="flex items-center">
                            <Users className="w-4 h-4 mr-2" />
                            <span>{place.visitor_count} visitors</span>
                          </div>
                          <span className="text-indigo-600 font-medium">
                            {place.price_range}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
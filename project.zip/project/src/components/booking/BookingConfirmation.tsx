import React from 'react';
import { CheckCircle, ArrowRight, Calendar, Users, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';

interface BookingConfirmationProps {
  bookingId: string;
  placeId: string;
  placeName: string;
  placeImage: string;
  placeLocation: string;
  checkIn: string;
  checkOut: string;
  guests: number;
  totalPrice: number;
}

const BookingConfirmation: React.FC<BookingConfirmationProps> = ({
  bookingId,
  placeId,
  placeName,
  placeImage,
  placeLocation,
  checkIn,
  checkOut,
  guests,
  totalPrice
}) => {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <div className="max-w-2xl mx-auto my-12 bg-white shadow-lg rounded-xl overflow-hidden">
      <div className="bg-green-50 p-6 flex flex-col items-center text-center border-b border-green-100">
        <CheckCircle size={64} className="text-green-500 mb-4" />
        <h1 className="text-2xl font-bold text-gray-800 mb-2">Booking Confirmed!</h1>
        <p className="text-gray-600">
          Your booking at {placeName} has been confirmed. Confirmation #: {bookingId.slice(0, 8)}
        </p>
      </div>
      
      <div className="p-6">
        <div className="flex flex-col md:flex-row gap-6 mb-8">
          <div className="md:w-1/3">
            <img 
              src={placeImage} 
              alt={placeName} 
              className="w-full h-40 object-cover rounded-lg"
            />
          </div>
          
          <div className="md:w-2/3">
            <h2 className="text-xl font-bold mb-2">{placeName}</h2>
            <div className="flex items-center text-gray-600 mb-4">
              <MapPin size={16} className="mr-1" />
              <span>{placeLocation}</span>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="flex items-start">
                <Calendar size={18} className="mr-2 text-blue-600 mt-0.5" />
                <div>
                  <div className="text-sm text-gray-500">Check-in</div>
                  <div className="font-medium">{formatDate(checkIn)}</div>
                </div>
              </div>
              
              <div className="flex items-start">
                <Calendar size={18} className="mr-2 text-blue-600 mt-0.5" />
                <div>
                  <div className="text-sm text-gray-500">Check-out</div>
                  <div className="font-medium">{formatDate(checkOut)}</div>
                </div>
              </div>
              
              <div className="flex items-start">
                <Users size={18} className="mr-2 text-blue-600 mt-0.5" />
                <div>
                  <div className="text-sm text-gray-500">Guests</div>
                  <div className="font-medium">{guests}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-gray-50 p-5 rounded-lg mb-8">
          <h3 className="text-lg font-semibold mb-4">Payment Details</h3>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-gray-600">Total Charge</span>
              <span className="font-medium">${totalPrice}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Payment Method</span>
              <span className="font-medium">Credit Card (XXXX-1234)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Date</span>
              <span className="font-medium">{new Date().toLocaleDateString()}</span>
            </div>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-4 justify-between">
          <Link 
            to={`/place/${placeId}`}
            className="inline-flex items-center justify-center px-5 py-2 border border-blue-600 text-blue-600 rounded-lg hover:bg-blue-50 transition-colors"
          >
            View Place Details
          </Link>
          
          <Link 
            to="/bookings"
            className="inline-flex items-center justify-center px-5 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            View All Bookings
            <ArrowRight size={16} className="ml-2" />
          </Link>
        </div>
      </div>
      
      <div className="bg-gray-50 p-4 text-center text-gray-500 text-sm border-t border-gray-200">
        <p>Thank you for booking with WanderGuide! If you need any assistance, please contact our support team.</p>
      </div>
    </div>
  );
};

export default BookingConfirmation;
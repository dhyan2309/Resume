import React from 'react';
import { Booking } from '../../types/types';
import { Calendar, MapPin, Users } from 'lucide-react';
import { Link } from 'react-router-dom';

interface BookingCardProps {
  booking: Booking;
  placeName: string;
  placeImage: string;
  placeLocation: string;
  onCancel?: (bookingId: string) => void;
}

const BookingCard: React.FC<BookingCardProps> = ({
  booking,
  placeName,
  placeImage,
  placeLocation,
  onCancel
}) => {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 overflow-hidden shadow-sm hover:shadow-md transition-shadow">
      <div className="flex flex-col sm:flex-row">
        <div className="sm:w-1/3 h-40 sm:h-auto">
          <Link to={`/place/${booking.placeId}`}>
            <img src={placeImage} alt={placeName} className="w-full h-full object-cover" />
          </Link>
        </div>
        
        <div className="sm:w-2/3 p-4">
          <div className="flex justify-between items-start mb-2">
            <Link to={`/place/${booking.placeId}`} className="hover:text-blue-600">
              <h3 className="text-lg font-bold">{placeName}</h3>
            </Link>
            <span className={`px-2 py-1 rounded-full text-xs font-medium capitalize ${getStatusColor(booking.status)}`}>
              {booking.status}
            </span>
          </div>
          
          <div className="flex items-center text-gray-600 mb-4">
            <MapPin size={16} className="mr-1" />
            <span className="text-sm">{placeLocation}</span>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-y-2 gap-x-4 mb-4">
            <div className="flex items-center text-sm text-gray-700">
              <Calendar size={16} className="mr-2 text-blue-600" />
              <div>
                <span className="font-medium">Check-in: </span>
                {formatDate(booking.checkIn)}
              </div>
            </div>
            
            <div className="flex items-center text-sm text-gray-700">
              <Calendar size={16} className="mr-2 text-blue-600" />
              <div>
                <span className="font-medium">Check-out: </span>
                {formatDate(booking.checkOut)}
              </div>
            </div>
            
            <div className="flex items-center text-sm text-gray-700">
              <Users size={16} className="mr-2 text-blue-600" />
              <div>
                <span className="font-medium">Guests: </span>
                {booking.guests}
              </div>
            </div>
            
            <div className="text-sm text-gray-700">
              <span className="font-medium">Total: </span>
              <span className="text-blue-600 font-semibold">${booking.totalPrice}</span>
            </div>
          </div>
          
          <div className="flex justify-between items-center">
            <div className="text-xs text-gray-500">
              Booked on {formatDate(booking.createdAt)}
            </div>
            
            {booking.status === 'confirmed' && onCancel && (
              <button 
                onClick={() => onCancel(booking.id)}
                className="px-3 py-1 bg-white border border-red-500 text-red-500 rounded hover:bg-red-50 text-sm transition-colors"
              >
                Cancel booking
              </button>
            )}
            
            {booking.status === 'confirmed' && (
              <Link 
                to={`/place/${booking.placeId}`}
                className="px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700 text-sm transition-colors"
              >
                View Details
              </Link>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookingCard;
import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, User, MapPin, Search, Heart } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const Header: React.FC = () => {
  const { isAuthenticated, user, logout } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleLogout = () => {
    logout();
    setIsMenuOpen(false);
  };

  const headerClass = isScrolled 
    ? 'fixed w-full bg-white shadow-md transition-all duration-300 z-50' 
    : 'fixed w-full bg-transparent transition-all duration-300 z-50';

  const linkClass = isScrolled
    ? 'text-gray-800 hover:text-blue-600 transition-colors duration-200'
    : location.pathname === '/' 
      ? 'text-white hover:text-blue-200 transition-colors duration-200'
      : 'text-gray-800 hover:text-blue-600 transition-colors duration-200';

  return (
    <header className={headerClass}>
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link to="/" className="flex items-center space-x-2 text-xl font-bold">
          <MapPin size={24} className={isScrolled || location.pathname !== '/' ? 'text-blue-600' : 'text-white'} />
          <span className={isScrolled || location.pathname !== '/' ? 'text-gray-800' : 'text-white'}>WanderGuide</span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-6">
          <Link to="/" className={`${linkClass} font-medium`}>Home</Link>
          <Link to="/places" className={`${linkClass} font-medium`}>Discover</Link>
          <Link to="/about" className={`${linkClass} font-medium`}>About</Link>

          {isAuthenticated ? (
            <div className="flex items-center space-x-4">
              <Link to="/favorites" className={`${linkClass} font-medium flex items-center`}>
                <Heart size={18} className="mr-1" />
                <span>Saved</span>
              </Link>
              <div className="relative group">
                <button className="flex items-center space-x-1 text-blue-600 font-medium">
                  <User size={18} />
                  <span>{user?.name}</span>
                </button>
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-50 hidden group-hover:block">
                  <Link 
                    to="/profile" 
                    className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    My Profile
                  </Link>
                  <Link 
                    to="/bookings" 
                    className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    My Bookings
                  </Link>
                  <button 
                    onClick={handleLogout}
                    className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    Sign Out
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex items-center space-x-4">
              <Link 
                to="/login" 
                className={`${linkClass} font-medium`}
              >
                Sign In
              </Link>
              <Link 
                to="/signup" 
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-full transition-colors duration-200 font-medium"
              >
                Sign Up
              </Link>
            </div>
          )}
        </nav>

        {/* Mobile Menu Button */}
        <button 
          className="md:hidden text-gray-600"
          onClick={toggleMenu}
          aria-label="Toggle menu"
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white shadow-lg">
          <div className="container mx-auto px-4 py-3">
            <nav className="flex flex-col space-y-3">
              <Link 
                to="/" 
                className="py-2 text-gray-800 hover:text-blue-600"
                onClick={() => setIsMenuOpen(false)}
              >
                Home
              </Link>
              <Link 
                to="/places" 
                className="py-2 text-gray-800 hover:text-blue-600"
                onClick={() => setIsMenuOpen(false)}
              >
                Discover
              </Link>
              <Link 
                to="/about" 
                className="py-2 text-gray-800 hover:text-blue-600"
                onClick={() => setIsMenuOpen(false)}
              >
                About
              </Link>
              {isAuthenticated ? (
                <>
                  <Link 
                    to="/favorites" 
                    className="py-2 text-gray-800 hover:text-blue-600 flex items-center"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    <Heart size={18} className="mr-2" />
                    Saved Places
                  </Link>
                  <Link 
                    to="/profile" 
                    className="py-2 text-gray-800 hover:text-blue-600"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    My Profile
                  </Link>
                  <Link 
                    to="/bookings" 
                    className="py-2 text-gray-800 hover:text-blue-600"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    My Bookings
                  </Link>
                  <button 
                    onClick={handleLogout}
                    className="py-2 text-left text-red-600 hover:text-red-700"
                  >
                    Sign Out
                  </button>
                </>
              ) : (
                <div className="flex flex-col space-y-2 pt-2">
                  <Link 
                    to="/login" 
                    className="py-2 text-gray-800 hover:text-blue-600"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Sign In
                  </Link>
                  <Link 
                    to="/signup" 
                    className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md text-center"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Sign Up
                  </Link>
                </div>
              )}
            </nav>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
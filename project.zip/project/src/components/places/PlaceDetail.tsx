import React, { useState } from 'react';
import { Place } from '../../types/types';
import { Star, MapPin, Calendar, Users, Heart, Share2, ArrowLeft } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';

interface PlaceDetailProps {
  place: Place;
  isFavorite?: boolean;
  onToggleFavorite?: (placeId: string) => void;
  onBook?: (checkIn: string, checkOut: string, guests: number) => void;
}

const PlaceDetail: React.FC<PlaceDetailProps> = ({ 
  place, 
  isFavorite = false,
  onToggleFavorite,
  onBook 
}) => {
  const navigate = useNavigate();
  const [checkIn, setCheckIn] = useState('');
  const [checkOut, setCheckOut] = useState('');
  const [guests, setGuests] = useState(1);
  const [bookingError, setBookingError] = useState('');

  const handleBookNow = () => {
    setBookingError('');
    
    if (!checkIn || !checkOut) {
      setBookingError('Please select check-in and check-out dates');
      return;
    }
    
    const checkInDate = new Date(checkIn);
    const checkOutDate = new Date(checkOut);
    
    if (checkInDate >= checkOutDate) {
      setBookingError('Check-out date must be after check-in date');
      return;
    }
    
    if (checkInDate < new Date()) {
      setBookingError('Check-in date cannot be in the past');
      return;
    }
    
    if (onBook) {
      onBook(checkIn, checkOut, guests);
    }
  };

  const getTotalNights = () => {
    if (!checkIn || !checkOut) return 0;
    
    const checkInDate = new Date(checkIn);
    const checkOutDate = new Date(checkOut);
    
    if (checkInDate >= checkOutDate) return 0;
    
    const diffTime = Math.abs(checkOutDate.getTime() - checkInDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return diffDays;
  };

  const getTotalPrice = () => {
    const nights = getTotalNights();
    return nights * place.price;
  };

  const handleFavoriteClick = () => {
    if (onToggleFavorite) {
      onToggleFavorite(place.id);
    }
  };

  return (
    <div className="bg-white">
      {/* Header */}
      <div className="relative h-96 md:h-[500px]">
        <img 
          src={place.imageUrl} 
          alt={place.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black opacity-60"></div>
        
        <div className="absolute top-4 left-4 z-10">
          <button 
            onClick={() => navigate(-1)}
            className="bg-white p-2 rounded-full shadow-md hover:bg-gray-100 transition-colors"
          >
            <ArrowLeft size={20} className="text-gray-700" />
          </button>
        </div>
        
        <div className="absolute bottom-0 left-0 w-full p-6 text-white">
          <h1 className="text-3xl md:text-4xl font-bold mb-2">{place.name}</h1>
          <div className="flex items-center space-x-2 mb-3">
            <MapPin size={18} />
            <span>{place.location}</span>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center">
              <Star size={18} className="text-yellow-400 mr-1" />
              <span>{place.rating} ({place.reviews.length} reviews)</span>
            </div>
            <span className="text-sm px-3 py-1 bg-blue-600 rounded-full">{place.category}</span>
          </div>
        </div>
      </div>
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Main Content */}
          <div className="lg:w-2/3">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold">About this place</h2>
              <div className="flex space-x-3">
                <button 
                  onClick={handleFavoriteClick}
                  className="flex items-center space-x-1 px-3 py-2 border border-gray-300 rounded-md hover:bg-gray-50 transition-colors"
                >
                  <Heart size={18} className={isFavorite ? 'fill-red-500 text-red-500' : 'text-gray-700'} />
                  <span>{isFavorite ? 'Saved' : 'Save'}</span>
                </button>
                <button className="flex items-center space-x-1 px-3 py-2 border border-gray-300 rounded-md hover:bg-gray-50 transition-colors">
                  <Share2 size={18} className="text-gray-700" />
                  <span>Share</span>
                </button>
              </div>
            </div>
            
            <p className="text-gray-700 mb-8">{place.description}</p>
            
            <div className="mb-8">
              <h3 className="text-xl font-semibold mb-4">Amenities</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {place.amenities.map((amenity, index) => (
                  <div key={index} className="flex items-center space-x-2 p-3 bg-gray-50 rounded-lg">
                    <span className="text-gray-700">{amenity}</span>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="mb-8">
              <h3 className="text-xl font-semibold mb-4">Location</h3>
              <div className="bg-gray-200 h-72 rounded-lg flex items-center justify-center">
                <p className="text-gray-500">Map view would be displayed here</p>
              </div>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold mb-4">Reviews ({place.reviews.length})</h3>
              <div className="space-y-4">
                {place.reviews.map(review => (
                  <div key={review.id} className="border-b border-gray-200 pb-4">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <div className="font-medium">{review.userName}</div>
                        <div className="text-sm text-gray-500">{review.date}</div>
                      </div>
                      <div className="flex items-center bg-blue-50 px-2 py-1 rounded">
                        <Star size={16} className="text-yellow-500 mr-1" />
                        <span className="font-medium">{review.rating}</span>
                      </div>
                    </div>
                    <p className="text-gray-700">{review.comment}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          {/* Booking Sidebar */}
          <div className="lg:w-1/3">
            <div className="bg-white border border-gray-200 rounded-xl shadow-lg p-6 sticky top-20">
              <div className="flex justify-between items-center mb-4">
                <div>
                  <span className="text-2xl font-bold text-blue-600">${place.price}</span>
                  <span className="text-gray-500"> / night</span>
                </div>
                <div className="flex items-center">
                  <Star size={16} className="text-yellow-400" />
                  <span className="ml-1 font-medium">{place.rating}</span>
                </div>
              </div>
              
              <div className="mb-4">
                <div className="grid grid-cols-2 gap-2 mb-4">
                  <div className="space-y-1">
                    <label className="block text-sm text-gray-600">Check-in</label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Calendar size={16} className="text-gray-400" />
                      </div>
                      <input 
                        type="date" 
                        className="pl-10 w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={checkIn}
                        onChange={(e) => setCheckIn(e.target.value)}
                        min={new Date().toISOString().split('T')[0]}
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-1">
                    <label className="block text-sm text-gray-600">Check-out</label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Calendar size={16} className="text-gray-400" />
                      </div>
                      <input 
                        type="date" 
                        className="pl-10 w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={checkOut}
                        onChange={(e) => setCheckOut(e.target.value)}
                        min={checkIn || new Date().toISOString().split('T')[0]}
                      />
                    </div>
                  </div>
                </div>
                
                <div className="space-y-1 mb-4">
                  <label className="block text-sm text-gray-600">Guests</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Users size={16} className="text-gray-400" />
                    </div>
                    <select 
                      className="pl-10 w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      value={guests}
                      onChange={(e) => setGuests(Number(e.target.value))}
                    >
                      {[1, 2, 3, 4, 5, 6].map(num => (
                        <option key={num} value={num}>
                          {num} {num === 1 ? 'guest' : 'guests'}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
              
              {bookingError && (
                <div className="text-red-500 text-sm mb-4 bg-red-50 p-2 rounded">
                  {bookingError}
                </div>
              )}
              
              <button 
                onClick={handleBookNow}
                className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors mb-4"
              >
                Book Now
              </button>
              
              {checkIn && checkOut && getTotalNights() > 0 && (
                <div className="border-t border-gray-200 pt-4">
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-600">
                      ${place.price} × {getTotalNights()} nights
                    </span>
                    <span>${place.price * getTotalNights()}</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-600">Service fee</span>
                    <span>${Math.round(place.price * getTotalNights() * 0.1)}</span>
                  </div>
                  <div className="flex justify-between font-bold mt-3 pt-3 border-t border-gray-200">
                    <span>Total</span>
                    <span>${getTotalPrice() + Math.round(place.price * getTotalNights() * 0.1)}</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlaceDetail;
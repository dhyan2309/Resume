import React, { useState } from 'react';
import { Place } from '../../types/types';
import PlaceCard from './PlaceCard';
import { Search, X } from 'lucide-react';

interface PlaceListProps {
  places: Place[];
  title?: string;
  favorites?: string[];
  onToggleFavorite?: (placeId: string) => void;
}

const PlaceList: React.FC<PlaceListProps> = ({ 
  places, 
  title = "Explore Destinations", 
  favorites = [],
  onToggleFavorite
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  
  const categories = ['All', 'Beach', 'Mountain', 'City', 'Desert'];
  
  const filteredPlaces = places.filter(place => {
    const matchesSearch = place.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          place.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          place.description.toLowerCase().includes(searchQuery.toLowerCase());
                          
    const matchesCategory = selectedCategory === null || 
                            selectedCategory === 'All' || 
                            place.category === selectedCategory;
                            
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-4 md:mb-0">{title}</h2>
        
        <div className="w-full md:w-auto flex flex-col sm:flex-row gap-4">
          {/* Search Input */}
          <div className="relative">
            <input
              type="text"
              placeholder="Search destinations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 w-full sm:w-64"
            />
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={18} className="text-gray-400" />
            </div>
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600"
              >
                <X size={18} />
              </button>
            )}
          </div>
          
          {/* Category Filter */}
          <div className="flex overflow-x-auto gap-2 pb-1 hide-scrollbar">
            {categories.map(category => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category === 'All' ? null : category)}
                className={`px-4 py-2 text-sm font-medium rounded-full whitespace-nowrap transition-colors ${
                  (category === 'All' && selectedCategory === null) || category === selectedCategory
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </div>
      
      {filteredPlaces.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-lg text-gray-600">No destinations found. Try adjusting your search.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredPlaces.map(place => (
            <PlaceCard 
              key={place.id} 
              place={place} 
              isFavorite={favorites.includes(place.id)}
              onToggleFavorite={onToggleFavorite}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default PlaceList;
import React from 'react';
import { Link } from 'react-router-dom';
import { Star, MapPin, Heart } from 'lucide-react';
import { Place } from '../../types/types';

interface PlaceCardProps {
  place: Place;
  isFavorite?: boolean;
  onToggleFavorite?: (placeId: string) => void;
}

const PlaceCard: React.FC<PlaceCardProps> = ({ 
  place, 
  isFavorite = false,
  onToggleFavorite
}) => {
  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (onToggleFavorite) {
      onToggleFavorite(place.id);
    }
  };

  return (
    <Link to={`/place/${place.id}`} className="block group">
      <div className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300">
        <div className="relative">
          <div className="h-48 overflow-hidden">
            <img 
              src={place.imageUrl} 
              alt={place.name}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
          </div>
          
          {onToggleFavorite && (
            <button 
              onClick={handleFavoriteClick}
              className="absolute top-3 right-3 p-2 bg-white bg-opacity-70 hover:bg-opacity-100 rounded-full transition-all duration-200"
            >
              <Heart size={20} className={isFavorite ? 'fill-red-500 text-red-500' : 'text-gray-600'} />
            </button>
          )}
          
          <div className="absolute bottom-0 left-0 w-full bg-gradient-to-t from-gray-900 to-transparent p-4 pt-8">
            <div className="flex justify-between items-end">
              <h3 className="text-xl font-bold text-white line-clamp-1">{place.name}</h3>
              <div className="flex items-center text-white bg-blue-600 px-2 py-1 rounded-lg text-sm">
                <Star size={14} className="fill-white text-white mr-1" />
                {place.rating}
              </div>
            </div>
          </div>
        </div>
        
        <div className="p-4">
          <div className="flex items-center text-gray-500 mb-2">
            <MapPin size={16} className="mr-1" />
            <span className="text-sm">{place.location}</span>
          </div>
          
          <p className="text-gray-600 mb-3 line-clamp-2 text-sm h-10">{place.description}</p>
          
          <div className="flex justify-between items-center">
            <div>
              <span className="text-blue-600 font-bold">${place.price}</span>
              <span className="text-gray-500 text-sm"> / night</span>
            </div>
            <div className="px-3 py-1 text-xs font-medium bg-gray-100 rounded-full text-gray-700">
              {place.category}
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default PlaceCard;